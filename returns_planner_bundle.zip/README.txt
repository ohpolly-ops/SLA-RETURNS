SLA Return Processing Planner (Simple HTML version)

- index.html: open this file in any browser or upload to your website.
- Fully self-contained, no external dependencies.

How it works:
1. Enter pallets, unpacked parcels, parcels per pallet, items per parcel, and rates.
2. Click Calculate.
3. The results will show required hours and SLA status.
